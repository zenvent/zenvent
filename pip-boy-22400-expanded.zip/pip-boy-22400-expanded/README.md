# PIP BOY / eCoupon / 22400 — expanded identity

Open preview.html. This pack contains the refined ORIGINAL rounded robot-terminal logo, 12 new role characters, 4 new avatar portraits, the previous 5 page characters and all 120 utility SVG icons.

## Files
- brand/pip-boy-ecoupon-22400-white.png: refined horizontal logo; transparent raster artwork.
- characters/: 17 full-body illustrations (12 new + 5 existing).
- avatars/: four head-and-shoulder profile portraits.
- svg/ and current-color/: 120 utility icons in each format.
- sprite.svg, icons.css and PipIcon.tsx: utility-icon integration.
- PipCharacter.tsx: typed React component for characters and avatars.
- field-map.json: field name → suggested character name.
- character-manifest.json: asset names, labels, paths and suggested fields.
- generation-prompts.json: built-in imagegen prompts for the new artwork.
- utility-icons.html: previous utility browser, updated with the refined logo.

## Tinting
All new art is PNG with transparency, not vector. CSS alpha masks preserve transparent details while making the visible artwork exactly your CSS color. Choose any of your existing three theme tokens. Masking works across arbitrary background colors.

```html
<link rel="stylesheet" href="/assets/pip-boy/icons.css">
<span class="pb-art pb-logo" role="img" aria-label="PIP BOY eCoupon 22400"></span>
<span class="pb-art pb-art-traces" aria-hidden="true"></span>
<span class="pb-art pb-avatar pb-art-avatar-engineer" role="img" aria-label="Engineer"></span>
```

```css
.pb-art { color: var(--theme-primary); }
.active .pb-art { color: var(--theme-accent); }
.pb-logo { width:360px; height:125px; }
```

## React
Copy characters/, avatars/ and svg/ to public/pip-boy/.

```tsx
<PipCharacter name="metrics" size={144} label="Metrics" />
<PipCharacter name="avatar-operator" size={48} label="On-call operator" />
<PipIcon name="branch" size={24} />
```

Prefer 96–200px for role artwork and 48–80px for avatars. The preview also shows 32px avatars so you can assess the loss of fine detail. Keep utility icons for dense fields and tables; use the characters for field groups, tabs, empty states, tool identities and section headers.

## Roles and suggested fields
- **Log Archivist**: `logs`, `events`, `timestamp`, `message`, `source`, `index`
- **Metrics Analyst**: `metrics`, `dashboards`, `rate`, `count`, `threshold`, `trend`
- **Trace Tracker**: `trace_id`, `span_id`, `parent_id`, `service`, `duration`, `dependency`
- **Incident Commander**: `alerts`, `severity`, `incident`, `on_call`, `acknowledged`, `status`
- **Bug Hunter**: `breakpoint`, `stack_frame`, `variable`, `watch`, `exception`, `debug`
- **Test Scientist**: `test_suite`, `assertion`, `coverage`, `passed`, `failed`, `test_duration`
- **Release Engineer**: `release`, `version`, `environment`, `pipeline`, `deployment`, `rollback`
- **Data Custodian**: `database`, `query`, `table`, `rows`, `connection_pool`, `query_time`
- **Network Operator**: `host`, `port`, `endpoint`, `http_method`, `http_status`, `region`
- **Performance Tuner**: `latency`, `p95`, `p99`, `cpu`, `memory`, `throughput`
- **Security Sentinel**: `permission`, `identity`, `secret`, `vulnerability`, `audit`, `access`
- **AI Sidekick**: `agent`, `model`, `prompt`, `context`, `tokens`, `tool_call`
- **Engineer**: `assignee`, `author`, `owner`
- **Operator**: `on_call_user`, `responder`, `operator`
- **Reviewer**: `reviewer`, `approver`, `maintainer`
- **Automation Bot**: `bot`, `automation`, `service_account`
- **Tasks**: `tasks`
- **Notes**: `notes`
- **Files**: `files`
- **Builds**: `builds`
- **Reviewer**: `reviewer`

Role research: https://docs.datadoghq.com/getting_started/ and https://help.splunk.com/en/splunk-observability-cloud/manage-data/metrics-metadata-and-events . These field assignments are design suggestions, not promises of exact vendor schemas.

Artwork generated with the built-in imagegen tool; raster files retained as supplied. The original pack remains available separately.
