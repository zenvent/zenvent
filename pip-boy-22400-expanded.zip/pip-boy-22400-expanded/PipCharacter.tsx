import type { CSSProperties } from 'react';
export type PipCharacterName = "logs" | "metrics" | "traces" | "incidents" | "debugger" | "tests" | "deployment" | "database" | "network" | "performance" | "security" | "ai-agent" | "avatar-engineer" | "avatar-operator" | "avatar-reviewer" | "avatar-bot" | "tasks" | "notes" | "files" | "builds" | "reviewer";
const files:Record<PipCharacterName,string> = {
  "logs": "characters/logs.png",
  "metrics": "characters/metrics.png",
  "traces": "characters/traces.png",
  "incidents": "characters/incidents.png",
  "debugger": "characters/debugger.png",
  "tests": "characters/tests.png",
  "deployment": "characters/deployment.png",
  "database": "characters/database.png",
  "network": "characters/network.png",
  "performance": "characters/performance.png",
  "security": "characters/security.png",
  "ai-agent": "characters/ai-agent.png",
  "avatar-engineer": "avatars/avatar-engineer.png",
  "avatar-operator": "avatars/avatar-operator.png",
  "avatar-reviewer": "avatars/avatar-reviewer.png",
  "avatar-bot": "avatars/avatar-bot.png",
  "tasks": "characters/tasks.png",
  "notes": "characters/notes.png",
  "files": "characters/files.png",
  "builds": "characters/builds.png",
  "reviewer": "characters/reviewer.png"
};
type Props={name:PipCharacterName;size?:number;label?:string;assetBase?:string;style?:CSSProperties;className?:string};
/** Copy characters/ and avatars/ into public/pip-boy/. */
export function PipCharacter({name,size=128,label,assetBase='/pip-boy',style,className}:Props) {
 const mask=`url("${assetBase}/${files[name]}") center / contain no-repeat`;
 return <span className={className} role={label?'img':undefined} aria-label={label}
  aria-hidden={label?undefined:true} style={{display:'inline-block',width:size,height:size,
  backgroundColor:'currentColor',mask,WebkitMask:mask,verticalAlign:'middle',flexShrink:0,...style}}/>;
}
