# PIP BOY / eCoupon / 22400

120 individual silhouette icons plus five Fallout perk-style page illustrations.

Open preview.html in a browser. Search by name, test 16/20/24px versions, change any of the three palette swatches, and click an icon to copy its CSS class. The preview is self-contained and works offline.

## Files
- svg/: white standalone SVGs on transparent backgrounds, 64×64 viewBox.
- current-color/: SVGs for inline use with inherited CSS color.
- sprite.svg: symbol IDs start with pb-icon-, e.g. pb-icon-tasks.
- illustrations/: original transparent PNG page art for Tasks, Notes, Files, Builds and Reviewer. Use CSS masks to force the exact tint color, independent of source RGB.
- brand/: white and currentColor vector logo plus app icon. Lettering is vector geometry, with no font dependency.
- icons.css: mask classes for every icon and illustration.
- PipIcon.tsx: React component accepting name, size, label, assetBase and style.
- manifest.json: full names and categories.
- generation-prompts.json: prompts used by the built-in imagegen tool for the five page illustrations.

## Recommended: CSS masks (any of your three theme colors)
Copy the folder into your site's assets and preserve its relative structure.

```html
<link rel="stylesheet" href="/assets/pip-boy/icons.css">
<span class="pb-icon pb-tasks" aria-hidden="true"></span>
<span class="pb-icon pb-illustration pb-page-reviewer" role="img" aria-label="Reviewer"></span>
```

```css
:root { --theme-primary: #ffffff; --theme-secondary: #87ff88; --theme-accent: #ffbe62; }
.sidebar { color: var(--theme-primary); }
.sidebar .active { color: var(--theme-accent); }
.pb-illustration { color: var(--theme-secondary); }
```

Those colors are preview defaults; substitute the actual website palette. No artwork edits required. Keep icons decorative beside visible text. Supply an accessible label for standalone controls.

## React
Copy svg/ into public/pip-boy/svg/, then import PipIcon.tsx.

```tsx
<PipIcon name="reviewer" size={24} label="Reviewer" style={{ color:'var(--theme-accent)' }} />
```

## SVG sprite
Serve files from your app's HTTP origin (external SVG use may be blocked on file://).

```html
<svg width="24" height="24" aria-hidden="true" style="color:var(--theme-primary)">
  <use href="/assets/pip-boy/sprite.svg#pb-icon-builds"></use>
</svg>
```

Inline current-color SVGs inherit the parent's color. An SVG used through an img tag does not inherit parent CSS color; use the supplied mask classes for tinting. Repeated inline SVG copies contain mask IDs: prefer the sprite or CSS masks to avoid duplicate IDs.

## Sizing and art direction
Use utility icons at 20–32px; the preview also shows the 16px tradeoff. Use page illustrations at 96px or larger because their facial and prop detail needs room. The character illustrations are generated raster artwork; the utility icons and logo are vectors. Integration marks are simplified themed approximations. The 22400 unit designation is included in the logo and preview, rather than adding tiny unreadable numerals to controls.

Reference: Fallout 4 companion Pip-Boy interface, https://www.movilzona.es/2015/11/10/todas-las-funciones-de-la-pip-boy-app-de-fallout-4-en-ios-y-android/ ; perk illustration references, https://www.pngkey.com/detail/u2q8q8w7w7r5o0o0_fallout-4-masked-perk-chart-fallout-perk-icons/
